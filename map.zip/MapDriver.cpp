#include "MapLoader.h"
#include <iostream>
#include <string>
#include <any>
using namespace std;

MapLoader* Load() {
        MapLoader* mapLoader = new MapLoader();
        return mapLoader;
    }

 int main() {
     string filePath;

     Map* map=nullptr;

         cout << "Please select a map: ";
         cin >> filePath;
         MapLoader* mapLoader = Load();
         map = mapLoader->GetMap(filePath);
         map ->validate();
         exit(0);

     }


     

